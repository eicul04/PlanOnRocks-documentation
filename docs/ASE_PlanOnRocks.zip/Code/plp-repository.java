@Repository
public interface IPlpDataRepository extends JpaRepository<PlpDataEntity, Long> {

	Optional<PlpDataEntity> findByPlpNummerSequence_PlpNummer(long plpNummer);

	Optional<PlpDataEntity> findByKostenstelleAndJahr(String kostenstelle, int jahr);

}