public String validateJahr(Integer jahr) {
		if (jahr == null) {
			return messagesUtil.getI18nString("NewPlpDialogWrapper.jahr.required.message");
		} else if (jahr < 1970 || jahr > 2100) {
			return messagesUtil.getI18nString("NewPlpDialogWrapper.jahr.validate.message");
		}
		return null;
	}